﻿CREATE TABLE Category
(
	CategoryCode int primary key identity,
	CategoryName varchar(50) 
)
